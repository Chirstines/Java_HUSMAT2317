package theoryClass.week05;

public class ModifyElementsOfArray {
	
	//print out the elements of a array
	public static void printArray(int[] array) {
		for (int element : array) {
			System.out.printf("%4d",element);
		}
	}
	
	//This method is used to insert a element to a index of array.
	public static int[] insertElement(int[] array, int value, int index) {
		int[] newArray = new int[array.length + 1];
		for (int i = 0; i < index; i++) {
			newArray[i] = array[i];
		}
		newArray[index] = value;
		for (int i = index + 1; i < newArray.length; i++) {
			newArray[i] = array[i-1];
		}
		return newArray;
	}
	
	// This method is used to remove a element in array.
	public static int[] removeElementInIndex(int[] arr, int index) {
		int[] newArray = new int[arr.length - 1];
		for (int i = 0; i < index; i++) {
			newArray[i] = arr[i];
		}
		for (int i = index + 1; i < arr.length; i++) {
			newArray[i-1] = arr[i];
		}
		return newArray;
	}
	
	public static void modyfyElementAtIndex(int[] array, int indexModify, int valueModify) {
		array[indexModify] = valueModify;
	}
	
	public static void main(String[] args) {
		//Create a array
		int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		
		//Print the array
		System.out.println("Array now: ");
		printArray(array);
		System.out.println();
		
		//Insert a element
		int valueInsert = 13;
		int indexInsert = 3;
		array = insertElement(array, valueInsert, indexInsert);
		System.out.println("Array after insert element " + valueInsert + " to index " + indexInsert + " of array: ");
		printArray(array);
		System.out.println();
		System.out.println();
		
		//Remove a element
		System.out.println("Array now: ");
		printArray(array);
		System.out.println();
		int indexRemove = 2;
		array = removeElementInIndex(array, indexRemove);
		System.out.println("Array after remove element which has index " + indexRemove + ": ");
		printArray(array);
		System.out.println();
		System.out.println();
		
		//Remove a element
		System.out.println("Array now: ");
		printArray(array);
		System.out.println();
		int indexModify = 1;
		int valueModify = 100;
		modyfyElementAtIndex(array, indexModify, valueModify);
		System.out.println("Array after modified element at index " + indexModify + " into " + valueModify + ": ");
		printArray(array);	
	}
}
