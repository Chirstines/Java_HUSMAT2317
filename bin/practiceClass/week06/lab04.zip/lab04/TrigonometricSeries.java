package practiceClass.week06.lab04;

public class TrigonometricSeries {

}
